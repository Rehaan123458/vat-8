var bax;
bax = createSprite (200,200,100,100);
createCanvas (400,400);
canvasColor ("blue")

keyIsDown(right_arrow){
  canvasColor ("red")
}